export const useDarkMode = (initialValue) => {
  const [darkMode, setDarkMode] = useLocalStroage('geceModu', false);
  return [darkMode, setDarkMode];
};
